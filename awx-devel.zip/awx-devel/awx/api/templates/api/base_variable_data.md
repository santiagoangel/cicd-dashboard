# Retrieve {{ model_verbose_name|title }} Variable Data:

Make a GET request to this resource to retrieve all variables defined for this
{{ model_verbose_name }}.

# Update {{ model_verbose_name|title }} Variable Data:

Make a PUT request to this resource to update variables defined for this
{{ model_verbose_name }}.
