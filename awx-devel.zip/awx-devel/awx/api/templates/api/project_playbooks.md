# Retrieve {{ model_verbose_name|title }} Playbooks:

Make GET request to this resource to retrieve a list of playbooks available
for this {{ model_verbose_name }}.
