Make a GET request to this resource to retrieve aggregate statistics for Tower.

{% include "api/_new_in_awx.md" %}
