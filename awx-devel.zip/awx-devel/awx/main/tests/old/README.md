Old Tests
=========
This are the old django.TestCase / unittest.TestCase tests for Tower.

No new tests should be added to this folder. Overtime, we will be refactoring
tests out of this folder as py.test tests and into their respective functional
and unit folders.
